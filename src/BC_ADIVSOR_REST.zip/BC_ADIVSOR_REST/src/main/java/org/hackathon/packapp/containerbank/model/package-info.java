/**
 * The classes in this package represent ContainerBank's business layer.
 */
package org.hackathon.packapp.containerbank.model;


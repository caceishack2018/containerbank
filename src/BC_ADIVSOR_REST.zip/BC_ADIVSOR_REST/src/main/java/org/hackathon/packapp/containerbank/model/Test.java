package org.hackathon.packapp.containerbank.model;

public class Test {

	public Test(String name, String other) {
		super();
		this.name = name;
		this.other = other;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	private String name ;
	private String other;
	
}

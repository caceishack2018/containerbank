/**
 * The classes in this package represent the JPA implementation
 * of ContainerBank's persistence layer.
 */
package org.hackathon.packapp.containerbank.repository.jpa;

